package com.casanova.restaurante1203

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.casanova.restaurante1203.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // Este comando vai inicializar a variável depois da sua declaração.
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        // O comando 'inflate' ira criar uma view a partir do arquivo XML.
        binding = ActivityMainBinding.inflate(layoutInflater)
        // Parâmetro do método onCreate
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding.checkPizza.setOnClickListener{

            // Condição para as variáveis da pizza. Se o ícone for selecionado a quantidade exibida muda no aplicativo para '1'...
            if (binding.checkPizza.isChecked()){
                binding.editQuantidadePizza.setText("1")
                binding.textPrecoPizza.visibility = View.VISIBLE
            }else{
                //...e caso não for, permanece 0.
                binding.editQuantidadePizza.setText("0")
                binding.textPrecoPizza.visibility = View.GONE
            }
        }
            // Condição para as variáveis do hambúrguer. Idênticas às da pizza.
        binding.checkhamburguer.setOnClickListener{
            if (binding.checkhamburguer.isChecked()){
                binding.editQuantidadehamburguer.setText("1")
                binding.textPrecohamburguer.visibility = View.VISIBLE
            }else{
                binding.editQuantidadehamburguer.setText("0")
                binding.textPrecohamburguer.visibility = View.GONE
            }
        }
            // Condição para as variáveis da salada. Idênticas às da pizza.
        binding.checksalada.setOnClickListener{
            if (binding.checksalada.isChecked()){
                binding.editQuantidadesalada.setText("1")
                binding.textPrecosalada.visibility = View.VISIBLE
            }else{
                binding.editQuantidadesalada.setText("0")
                binding.textPrecosalada.visibility = View.GONE
            }
        }

    }
}